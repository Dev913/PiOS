from os import system
system('sudo pip install pyyaml')
system('sudo pip install cryptography==2.4.2')
system('sudo pip install python3-paramiko')
