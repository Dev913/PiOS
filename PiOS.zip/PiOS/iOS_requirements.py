from os import system
import yaml
import paramiko
system('reset')
f=open('Data//Data.yaml')
data=yaml.load(f)
ip=data['ip']
port=data['port']
username=data['username']
password=data['password']

client = paramiko.SSHClient()
client.load_system_host_keys()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(ip, port=port, username=username, password=password, sock=None)
client.exec_command('apt-get install com.clarkecdc.open')